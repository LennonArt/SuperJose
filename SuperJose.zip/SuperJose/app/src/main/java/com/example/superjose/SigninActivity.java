package com.example.superjose;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SigninActivity extends AppCompatActivity {

    EditText tbName, tbAddress, tbMobilenumber, tbRegisterPassword, tbConfirmPassword;
    Button btnRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        tbName = findViewById(R.id.tbName);
        tbAddress = findViewById(R.id.tbAddress);
        tbMobilenumber = findViewById(R.id.tbMobilenumber);
        tbRegisterPassword = findViewById(R.id.tbRegisterPassword);
        tbConfirmPassword = findViewById(R.id.tbConfirmPassword);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tbRegisterPassword.getText().toString().equals(tbConfirmPassword.getText().toString())){
                    startActivity(new Intent(SigninActivity.this, RegisteredSuccessfullyActivity.class));
                }
                else{
                    Toast.makeText(SigninActivity.this, "Your password doesn't matched with your confirmed password. Try again!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}